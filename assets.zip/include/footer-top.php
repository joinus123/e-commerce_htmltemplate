<div class="container">
                  <div class="row">
                  <div class="col-md-12">
                     <div class="email-sec text-center">
                        <div class="email-content">
                           <div class="email-heading">
                              <h2>get our latest update <span>in your email</span> </h2>
                           </div>
                           <div class="email-pera m-4">
                              <p>Subscribe now to get 15% off on any product</p>
                           </div>
                        </div>
                        <div class="email-box">
                           <input type="text" class="form-control col-md-6" id="usr" name="username" placeholder="Email address">
                           <div class="subcribe-btn-sec">
                              <a href="#" class="subcribe-btn col-12">subcribe</a>
                           </div>
                        </div>
                     </div>
                  </div>
               <div class="footer-img-gallery">
                  <div class="row">
                     <div class="col-md-2 col-4 col1 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                     <div class="col-md-2 col-4 col2 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery2.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                     <div class="col-md-2 col-4 col3 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery3.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                     <div class="col-md-2 col-4 col4 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery4.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                     <div class="col-md-2 col-4 col5 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery5.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                     <div class="col-md-2 col-4 col6 p_0">
                        <div class="footer-gallery-img">
                           <img src="assets/images/footer-gallery6.png" class="img-fluid" alt="img-1">
                        </div>
                        <div class="img-insta"><img src="assets/images/insta.png" class="img-fluid" alt="img2"></div>
                     </div>
                  </div>
               </div>
               </div>
            </div>
