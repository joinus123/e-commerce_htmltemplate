<?php include"include/header.php" ?>
<!-- aboutus-section -->
<section class="compare-page">
   <div class="compare-page-wrapper">
      <div class="banner">
         <div class="col-md-12">
            <div class="sub-page-heading">
               <div class="container">
                  <h2>Compare Product</h2>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-6">
               <div class="compare-product-wrapper mb-5">
                  <div class="compare-img">
          
      
                              <a href="#">
                              <img class="pic-1" src="assets/images/seller-img2.png" class="img-fluid">
                              </a>
 
                           <div class="comapre-content text-center pb-3">
                              <h5><a href="product-detail.php">TAP™ ADVANCED COMMAND TRAINER</a></h5>
                              <div class="prices"><h6>$11.00 - $15.00</h6>
                                <div class="add-card custom-btn"><i class="fa fa-shopping-cart"></i> Add to Card</div>
                              </div>
                           </div>
                       </div>
                     <div class="compare-detail">
                        <div class="compare-weight d-flex">
                        <h5>weight</h5>
                        <p>no</p>
                        </div>
                        <div class="compare-pera pt-5 pb-5">
                           <h4>Description:</h4>
                           <p>The First Responder Resistance Tubing was designed to activate and strengthen muscles on the inside of the elbow and for pronation neuromuscular re-education drills to protect the Ulnar Collateral Ligament (UCL). The UCL is also known as the ‘Tommy John Ligament’.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                           consequat.</p>
                           <p> Duis aute irure dolor in reprehenderit in voluptate velit esse
                           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        </div>
                     </div>
                     <div class="compare-video">
                          <div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://youtu.be/0eTsmcUjrxk"></iframe>
     </div>
    <div class="pera pt-5 pb-5">
       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
       quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
       consequat.</p>
       <p> Duis aute irure dolor in reprehenderit in voluptate velit esse
       cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
       proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
  </div>
                    
                     <div class="short-detail">
                       <h4>Short Description:</h4>
                       <p>The First Responder device uses resistance tubing to strengthen muscles in the forearm for increased arm health.</p>
                     </div>
                     <div class="short-list">
                       <ul>
                         <li>Arm health <span>2</span></li>
                         <li>UCL protection</li>
                         <li>Improves deceleration pattern</li>
                         <li>SKU</li>
                         <li>Color</li>
                         <li>size</li>
                         <li>resistance</li>
                       </ul>
                     </div>
                
    
            </div>
         </div>
                     <div class="col-md-6">
               <div class="compare-product-wrapper mb-5">
                  <div class="compare-img">
          
      
                              <a href="#">
                              <img class="pic-1" src="assets/images/seller-img2.png" class="img-fluid">
                              </a>
 
                           <div class="comapre-content text-center pb-3">
                              <h5><a href="product-detail.php">TAP™ ADVANCED COMMAND TRAINER</a></h5>
                              <div class="prices"><h6>$11.00 - $15.00</h6>
                                <div class="add-card custom-btn"><i class="fa fa-shopping-cart"></i> Add to Card</div>
                              </div>
                           </div>
                       </div>
                     <div class="compare-detail">
                        <div class="compare-weight d-flex">
                        <h5>weight</h5>
                        <p>no</p>
                        </div>
                        <div class="compare-pera pt-5 pb-5">
                           <h4>Description:</h4>
                           <p>The First Responder Resistance Tubing was designed to activate and strengthen muscles on the inside of the elbow and for pronation neuromuscular re-education drills to protect the Ulnar Collateral Ligament (UCL). The UCL is also known as the ‘Tommy John Ligament’.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                           tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                           quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                           consequat.</p>
                           <p> Duis aute irure dolor in reprehenderit in voluptate velit esse
                           cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                           proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        </div>
                     </div>
                     <div class="compare-video">
                          <div class="embed-responsive embed-responsive-16by9">
    <iframe class="embed-responsive-item" src="https://youtu.be/0eTsmcUjrxk"></iframe>
     </div>
    <div class="pera pt-5 pb-5">
       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
       quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
       consequat.</p>
       <p> Duis aute irure dolor in reprehenderit in voluptate velit esse
       cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
       proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    </div>
  </div>
                    
                     <div class="short-detail">
                       <h4>Short Description:</h4>
                       <p>The First Responder device uses resistance tubing to strengthen muscles in the forearm for increased arm health.</p>
                     </div>
                     <div class="short-list">
                       <ul>
                         <li>Arm health <span>2</span></li>
                         <li>UCL protection</li>
                         <li>Improves deceleration pattern</li>
                         <li>SKU</li>
                         <li>Color</li>
                         <li>size</li>
                         <li>resistance</li>
                       </ul>
                     </div>
                
    
            </div>
         </div>
      </div>
   </div>
</section>
<!-- end-aboutus-section -->
<!-- footer -->
<?php include"include/footer.php" ?>