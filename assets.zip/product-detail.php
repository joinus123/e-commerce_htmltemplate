<?php include"include/header.php" ?>
      <section class="product-detail">
         <div class="product-detail-wrapper">
                                                <div class="banner">
                         
                        <div class="col-md-12">
                        <div class="sub-page-heading">
                           <div class="container">
                           <h2>Product Detail</h2>
                        </div>
                        </div>
                     </div>
               
                     </div>
            <div class="container">
               <div class="row h-100 justify-content-center justify-item-center">
                  <div class="col-md-6">
  <div class="image-viewer">
    <div class="main-image">
      <img src="assets/images/seller-img2.png" class="img-fluid">
    </div>
    <div class="secondary-images">
      <div class="secondary-image">
         <img src="assets/images/seller-img1.png" class="img-fluid">
      </div>
      <div class="secondary-image">
         <img src="assets/images/seller-img2.png" class="img-fluid">
      </div>
      <div class="secondary-image">
         <img src="assets/images/seller-img1.png" class="img-fluid">
      </div>
      <div class="secondary-image">
         <img src="assets/images/seller-img2.png" class="img-fluid">
      </div>
    </div>
  </div>
  <div class="detail">

  </div>

  <div class="lightbox" id="lightbox">
    <img src="http://placehold.it/650x650"/>
    <div class="lightbox-controls">
      <div class="lightbox-controls-close">
        <i class="fa fa-times" aria-hidden="true"></i>
      </div>

    </div>
  </div>
  
                                          </div>
                        <div class="details col-md-6">
                                          <h3 class="product-title">lorem ipsum lorem</h3>
                                          <div class="rating">
                                             <div class="stars">
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star checked"></span>
                                                <span class="fa fa-star"></span>
                                                <span class="fa fa-star"></span>
                                             </div>
                                             <span class="review-no">41 reviews</span>
                                          </div>
                                          <div class="pera">
                                          <p class="product-description">Suspendisse quos? Tempus cras iure temporibus? Eu laudantium cubilia sem sem! Repudiandae et! Massa senectus enim minim sociosqu delectus posuere.</p>
                                          </div>
                                          <div class="action mt-4">
                                             <a href="cart.php" class=" custom-btn">add to cart</a>
                                          </div>
                                       </div>
                        </div>
                    </div>      
                </div>
      </section>
      <!-- end-product-detail -->
      <!-- footer -->
<?php include"include/footer.php" ?>