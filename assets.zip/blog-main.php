<?php include"include/header.php" ?>
<!-- aboutus-section -->
<section class="blog-page">
   <div class="blog-page-wrapper">
      <div class="banner">
         <div class="col-md-12">
            <div class="sub-page-heading">
               <div class="container">
                  <h2>Blog</h2>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="blog-main-sec">
   <div class="container-fluid">
      <div class="row">
<!--          <div class="col-md-6">
            <div class="blog">
               <div class="title">
                  <h5 class="mb-2">Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                  <p> dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                     quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                     consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                     cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                     proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                  </p>
               </div>
            </div>
         </div> -->
<!--                   <div class="col-md-6">
            <div class="blog-img">
               <img src="assets/images/allproduct-6.png" class="fluid" alt="img">
            </div>
         </div> -->
         <div class="blog spacing">
                  <div class="row h-100 align-content-center align-items-center">

                     <div class="col-lg-6">
                                          <h5 class="mb-2">Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                        <div class="pera">
                           <p>Robert brings with him a wealth of experience acquired from 33 years of working in school administration in capacities including department head, school principal, and assistant superintendent. In addition to a career in education, he was co-owner of a private security company from 1973--1990. Robert retired from school administration in 2003, and not being one satisfied to simply relax, he immediately founded Oates Specialties LLC. Robert enjoys talking to customers when they seek out his advice and when they have success stories to share after using Oates Specialties equipment.</p>
                           <p>Gloria retired in 2004 after a 29-year career and also devotes her time to the company. Like Robert, her many years of administrative experience as well as a business degree was a good fit in operating a small business.</p>
                           <p>In their spare time, Robert and Gloria enjoy traveling and spending time with family and friends.</p>
                           <p> Please feel free to call  us anytime we can help with your training needs.  We appreciate your business!</p>
                        </div>
                     </div>
                     <div class="col-lg-6">
                        <div class="blog-sub-img">
                        <img src="assets/images/blog.png" class="img-fluid" alt="image">
                     </div>
                     </div>
                  </div>
               </div>

      </div>
   </div>
   </div>
</section>
<!-- end-aboutus-section -->
<!-- footer -->
<?php include"include/footer.php" ?>