<?php include"include/header.php" ?>
         <section>
            <div class="affiliate-home-wrapper pera_padding footer-inner">
                           <div class="banner">
                        <div class="col-md-12">
                        <div class="sub-page-heading">
                           <div class="container">
                           <h2>AFFILIATE PROGRAM</h2>
                           </div>
                        </div>
                     </div>

                     </div>
               <div class="container">
<!--                   <div class="row">
                     <div class="col-md-12">
                        <div class="heading">
                           <h2>AFFILIATE PROGRAM</h2>
                        </div>
                     </div>
                  </div> -->
                  <div class="row">
                     <div class="col-lg-12">
                        <div class="sub-heading pt-3">
                           JOIN THE OATES SPECIALTIES AFFILIATE TEAM
                        </div>
                        <p>Partner with us to provide quality fitness conditioning equipment to elite athletes. If you have a web site, blog, or team web page, you can join our program promoting the products from OatesSpecialties.com and earn commissions for every sale!</p>
                        <p>
                           It's easy and it's free to join! The Oates Specialties Affiliate program is a great way to add a revenue stream to your existing business or raise funds for your team or organization.
                        </p>
                        <p>
                           There is no charge to become an Internet Affiliate and there is no limit to how much you can earn. We will provide links for you to place on your site or you can create your own. Every time a customer links to our site from yours and purchases an eligible product, you will earn a 10 % commission on the sale. Commissions are paid monthly on balances of $50.00 or more.
                        </p>
                        <p>We will process the order, ship the merchandise, and handle the customer service. It's that simple, and as an Oates Specialties Online Internet Affiliate, you can be assured you are sending your visitors to the best collection of athletic conditioning tools available in the market today.</p>
                        <p>In order to become an Oates Specialties Affiliate, you must have a web presence that you own and operate. Oates Specialties LLC reserves the right to review and approve your web presence for acceptance into our Affiliate Program. Our requirements are simple and include the following:</p>
                        <ul>
                           <li>
                              <p>Your web presence must be sport or fitness oriented</p>
                           </li>
                           <li>
                              <p>You must be the owner of the website, webpage or blog linking to OatesSpecialties.com - your web presence will be verified prior to issuing payment</p>
                           </li>
                           <li>
                              <p>Facebook profiles, pages, or other social media pages do not qualify as affiliates</p>
                           </li>
                           <li>
                              <p>An affiliate must have a mailing address and physical address in the USA</p>
                           </li>
                           <li>
                              <p>Your website may not use spam or employ deceptive practices</p>
                           </li>
                        </ul>
                        <p>While a majority of affiliate applicants will be allowed to participate in the program, we reserve the right to refuse or revoke any site containing offensive material, including pornography, explicit language, or offensive content.</p> 
                        <p>We also reserve the right to refuse participation in the Affiliate Program or to revoke an Affiliate's account for any reason without prior notice.</p>
                        <p>HOW DO I JOIN?</p>
                        <ul>
                           <li><p>Read our Affiliate Operating Agreement available at www.OatesSpecialties.com</p></li>
                           <li><p>Complete the Online Application</p></li>
                           <li><p>If you are accepted, we will send you all the information and tools needed to get started selling OatesSpecialties.com products on your site, while you make a commission on every eligible sale</p></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      <!--END ABOUT RESISTANCE TUBING -->
      <!-- footer -->
<?php include"include/footer.php" ?>