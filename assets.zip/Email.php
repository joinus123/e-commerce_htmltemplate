<?php include"include/header.php" ?>
      <section class="email">
               <div class="email-wrapper li-spacing inner-page">
                                              <div class="banner">
                            
                        <div class="col-md-12">
                        <div class="sub-page-heading">
                           <div class="container">
                           <h2>Email</h2>
                        </div>
                        </div>
                  
                     </div>
                     </div>
               <div class="container">
               <div class="row">
      <div class="col-md-6">
        <h2 class="text-uppercase mt-3 font-weight-bold text-white">CONTATTACI</h2>
        <form action="">
          <div class="row">
            <div class="col-lg-6">
              <div class="form-group">
                <input type="text" class="form-control mt-2" placeholder="First Name" required>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <input type="text" class="form-control mt-2" placeholder="Last Name" required>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <input type="email" class="form-control mt-2" placeholder="Email" required>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="form-group">
                <input type="number" class="form-control mt-2" placeholder="Tele" required>
              </div>
            </div>
            <div class="col-12">
              <div class="form-group">
                <textarea class="form-control" id="exampleFormControlTextarea1" placeholder="Comment" rows="3" required></textarea>
              </div>
            </div>
            <div class="col-12">
            <div class="form-group">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
                <label class="form-check-label" for="invalidCheck2">
                  Remember Me
                </label>
              </div>
            </div>
            </div>
            <div class="col-12">
              <a href="#" class="custom-btn" type="submit">submit</a>
            </div>
          </div>
        </form>

      </div>
      <div class="col-md-6">
<div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=155%20FM%201696%20East%20%20Huntsville%2C%20TX%2077320&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Google Maps Generator by <a href="https://www.embedgooglemap.net">embedgooglemap.net</a></div><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div>

    </div>




               </div>
      </section>
      <!-- end-contactus-section -->
      <!-- footer -->
<?php include"include/footer.php" ?>