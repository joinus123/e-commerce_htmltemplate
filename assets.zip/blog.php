<?php include"include/header.php" ?>
<!-- aboutus-section -->
<section class="blog-page">
   <div class="blog-page-wrapper">
      <div class="banner">
         <div class="col-md-12">
            <div class="sub-page-heading">
               <div class="container">
                  <h2>Blog</h2>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="blog-list-wrapper">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="blog-list">
               <div class="blog-list-text">
                  <h5>Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                  <p> dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua.
                  </p>
                  <a href="blog-main.php" class="custom-btn text-center">read more</a>
               </div>
               <div class="blog-list-img"> 
               <img src="assets/images/ceo.jpg" class="img-fluid" alt="Thumbnail">
                  </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="blog-list">
               <div class="blog-list-text">
                  <h5>Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                  <p> dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua.
                  </p>
                  <a href="blog-main.php" class="custom-btn text-center">read more</a>
               </div>
               <div class="blog-list-img"> 
               <img src="assets/images/ceo.jpg" class="img-fluid" alt="Thumbnail">
                  </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="blog-list mt-5">
               <div class="blog-list-text">
                  <h5>Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                  <p> dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua.
                  </p>
                  <a href="blog-sub-page.php" class="custom-btn text-center">read more</a>
               </div>
               <div class="blog-list-img"> 
               <img src="assets/images/ceo.jpg" class="img-fluid" alt="Thumbnail">
                  </div>
            </div>
         </div>
         <div class="col-md-6">
            <div class="blog-list mt-5">
               <div class="blog-list-text">
                  <h5>Lorem ipsum</h5>
                  <h3 class="mb-0">
                     Lorem ipsum
                  </h3>
                  <p> dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                     tempor incididunt ut labore et dolore magna aliqua.
                  </p>
                  <a href="blog-sub-page.php" class="custom-btn text-center">read more</a>
               </div>
               <div class="blog-list-img"> 
               <img src="assets/images/ceo.jpg" class="img-fluid" alt="Thumbnail">
                  </div>
            </div>
         </div>
      </div>
   </div>
</div>
</section>
<!-- end-aboutus-section -->
<!-- footer -->
<?php include"include/footer.php" ?>