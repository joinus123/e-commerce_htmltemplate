<?php include"include/header.php" ?>
                                 <div class="banner">
                           
                        <div class="col-md-12">
                        <div class="sub-page-heading">
                           <div class="container">
                           <h2>Videos</h2>
                        </div>
                        </div>
                 
                     </div>
                     </div>

      <section class="video spacing">
         <div class="container">
            <div class="row">
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="video-border">
                     <video controls>
                        <source src="#">
                     </video>
                  </div>
                  <div class="play-video">
                     <a data-fancybox="gallery" href="https://www.w3schools.com/tags/mov_bbb.mp4">
                     <img src="assets/images/video-btn.png" class="img-fluid" alt="play"></a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- footer -->
<?php include"include/footer.php" ?>