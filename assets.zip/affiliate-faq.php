<?php include"include/header.php" ?>
      <!-- ABOUT RESISTANCE TUBING -->
         <section>
            <div class="affiliate-faq-wrapper pera_padding footer-inner">
                     <div class="banner">
                        <div class="col-md-12">
                        <div class="sub-page-heading">
                           <div class="container">
                           <h2>Affilate faq</h2>
                           </div>
                        </div>
                     </div>
                     </div>

               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="heading mt-5">
                           <h2>AFFILIATE PROGRAM FREQUENTLY ASKED QUESTIONS</h2>
                        </div>
                     </div>
                     <div class="col-lg-12">
                        <p>OATES SPECIALTIES LLC has compiled this information so that you may be better informed about our Affiliate Program.</p>
                        <p>If you have any questions please <a href="#"> Contact Us</a> for more information.</p>
                        <ul>
                           <li><a href="#" class="affiliate-faq1">What are the requirements to be an Oates Specialties Affiliate?</a></li>
                           <li><a href="#" class="affiliate-faq2">How Do I Join?</a></li>
                        </ul>
                        <hr>
                        <div class="sub-heading pt-3">
                          Frequently Asked Questions
                        </div>
                        <div class="sub-heading pt-3 pb-3">
                          What are the requirements to be an Oates Specialties Affiliate?
                        </div>
                        <div class="affiliate-sub-faq1">
                        <ul>
                           <li>You must have a web presence that you own and operate</li>
                           <li>Your web presence must be sport or fitness oriented</li>
                           <li>You must be the owner of the website, webpage or blog linking to OatesSpecialties.com</li>
                           <li>We do not accept Facebook profiles, pages or other social media pages as affiliates</li>
                           <li>Affiliate must have mailing address and physical address in the USA</li>
                           <li>Your website may not use spam or employ deceptive practices</li>
                        </ul>
                     </div>
                        <div class="sub-heading pt-3 pb-3">
                         How Do I Join?
                        </div>
                        <div class="affiliate-sub-faq2">
                        <ul>
                           <li>Read our Affiliate Operating Agreement</li>
                           <li>Complete the Online Application</li>
                        </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      <!--END ABOUT RESISTANCE TUBING -->
      <!-- footer -->
<?php include"include/footer.php" ?>